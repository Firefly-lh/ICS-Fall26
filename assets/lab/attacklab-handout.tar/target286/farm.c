/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_256(unsigned *p)
{
    *p = 2428995912U;
}

void setval_447(unsigned *p)
{
    *p = 3347662866U;
}

unsigned addval_169(unsigned x)
{
    return x + 1215262898U;
}

unsigned addval_481(unsigned x)
{
    return x + 3284633920U;
}

unsigned getval_134()
{
    return 1482574465U;
}

unsigned addval_116(unsigned x)
{
    return x + 834900056U;
}

unsigned addval_267(unsigned x)
{
    return x + 3284633960U;
}

unsigned getval_266()
{
    return 3281293400U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_305(unsigned x)
{
    return x + 3374367369U;
}

unsigned getval_414()
{
    return 2429651965U;
}

unsigned getval_208()
{
    return 2464188744U;
}

unsigned getval_124()
{
    return 2497743176U;
}

unsigned addval_264(unsigned x)
{
    return x + 3507039901U;
}

unsigned addval_402(unsigned x)
{
    return x + 3676360201U;
}

void setval_224(unsigned *p)
{
    *p = 3682910857U;
}

void setval_284(unsigned *p)
{
    *p = 3682914697U;
}

unsigned addval_444(unsigned x)
{
    return x + 3531129481U;
}

void setval_141(unsigned *p)
{
    *p = 3524841097U;
}

void setval_216(unsigned *p)
{
    *p = 3264266889U;
}

void setval_401(unsigned *p)
{
    *p = 3380923913U;
}

unsigned addval_388(unsigned x)
{
    return x + 3525362377U;
}

unsigned addval_195(unsigned x)
{
    return x + 3380924813U;
}

void setval_149(unsigned *p)
{
    *p = 3252717896U;
}

void setval_173(unsigned *p)
{
    *p = 2425409929U;
}

void setval_123(unsigned *p)
{
    *p = 3227569801U;
}

unsigned addval_246(unsigned x)
{
    return x + 3676360333U;
}

void setval_187(unsigned *p)
{
    *p = 3286272328U;
}

void setval_262(unsigned *p)
{
    *p = 2425672073U;
}

void setval_434(unsigned *p)
{
    *p = 3286272328U;
}

void setval_312(unsigned *p)
{
    *p = 3676360329U;
}

unsigned addval_496(unsigned x)
{
    return x + 3286272360U;
}

unsigned getval_163()
{
    return 3286273352U;
}

unsigned addval_371(unsigned x)
{
    return x + 2429659464U;
}

void setval_143(unsigned *p)
{
    *p = 3348152969U;
}

void setval_420(unsigned *p)
{
    *p = 3229929897U;
}

unsigned addval_259(unsigned x)
{
    return x + 3374370505U;
}

void setval_146(unsigned *p)
{
    *p = 2445445403U;
}

void setval_467(unsigned *p)
{
    *p = 3286239560U;
}

unsigned getval_418()
{
    return 3525362315U;
}

unsigned getval_159()
{
    return 3380924041U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
